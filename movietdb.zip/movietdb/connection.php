<?php   
    $connection = mysqli_connect('localhost:3309','root','');
    $db = mysqli_select_db($connection,'movietdb');
?>