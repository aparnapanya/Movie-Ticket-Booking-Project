<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Home Page</title>
		<!-- Bootsrap Files -->
		<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"></link>
		<!--script type="text/javascript" src="bootstrap/js/bootstrap.min.js"--><!--/script-->
		<!-- CSS Files -->
		<link rel="stylesheet" href="css/style.css">
  </head>
  <body style=" background-color:rgb(15,81,116);background-image: url('https://ktla.com/wp-content/uploads/sites/4/2022/09/movie-theater-popcorn.jpg?w=2560&h=1440&crop=1');
   background-size:contain;
  background-repeat:no-repeat;
  overflow: hidden;
  width:1300px;
  height:300vh;">

}



    <!-- Header code starts here width:1300px;
  height:200vh;-->
   
    <div class="row" id="header">
      <div class="col-md-5" >
        <h4 style="padding-left:15px;font-family:'Comic Sans MS';">Cinema Hungama</h4>
      </div>
      <div class="col-md-7" style="text-align: right;">
        <ul>
          <li><a href="index.php" class="active">Home</a></li>
          <!--li><a href="movies.php">Movies</a></li-->
          <li><a href="register.php">Register</a></li>
          <li><a href="login.php">Login</a></li>
          <li><a href="admin/login.php">Admin login</a><li>
        </ul>
      </div>
    </div>
    </body>

</html>
    